import 'package:flutter/material.dart';
import '../models/product.dart';
import '../services/product_service.dart';

class ProductFormScreen extends StatefulWidget {
  final Product? product;

  const ProductFormScreen({super.key, this.product});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final service = ProductService();

  late TextEditingController title;
  late TextEditingController price;
  late TextEditingController description;

  @override
  void initState() {
    super.initState();
    title = TextEditingController(text: widget.product?.title ?? '');
    price = TextEditingController(text: widget.product?.price.toString() ?? '');
    description = TextEditingController(text: widget.product?.description ?? '');
  }

  void save() async {
    if (!_formKey.currentState!.validate()) return;

    final product = Product(
      id: widget.product?.id,
      title: title.text,
      price: double.parse(price.text),
      description: description.text,
      category: "general",
      image: "",
    );

    if (widget.product == null) {
      await service.addProduct(product);
    } else {
      await service.updateProduct(product);
    }

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.product == null ? 'Cadastrar' : 'Editar')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(controller: title, decoration: const InputDecoration(labelText: 'Nome')),
              TextFormField(controller: price, decoration: const InputDecoration(labelText: 'Preço')),
              TextFormField(controller: description, decoration: const InputDecoration(labelText: 'Descrição')),
              const SizedBox(height: 20),
              ElevatedButton(onPressed: save, child: const Text('Salvar'))
            ],
          ),
        ),
      ),
    );
  }
}
